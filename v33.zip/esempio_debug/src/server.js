const express = require('express')
const app = express()

citta=['Roma','Torino','Milan','Firenze','Bari','Napoli','Genova', 'Trento']

app.get('/citta',(req,res) => {
		  console.log("nuova richiesta...")
		  res.status(200).send(citta)
})

app.listen(5555, '0.0.0.0')
