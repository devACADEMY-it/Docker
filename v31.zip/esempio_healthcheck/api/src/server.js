const express = require('express')
const app = express()

citta=['Roma','Torino','Milano','Firenze','Bari','Napoli']

app.get('/citta',function(req,res){
		  res.status(200).send(citta)
})

app.listen(8888, '0.0.0.0')
