const axios = require('axios');

 axios.get('http://api:4444/donazioni/ultime')
  .then(response => {
    for (x of response.data) {
       console.log(`${x.provincia} ${x.importo}`)
    }
  })
  .catch(error => {
    console.log(error);
  })
