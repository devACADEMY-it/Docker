const express = require('express')
    
const app = express()

app.use(function(req, res, next) {
	res.header("Access-Control-Allow-Origin", "*"); 
	res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  	next()
})

app.get('/donazioni/ultime',function(req,res){
   
    result=[{'provincia':'NA', 'importo':45},{'provincia':'PA', 'importo':60}]
    res.status(200).send(JSON.stringify(result))
})


app.listen(4444, '0.0.0.0')
