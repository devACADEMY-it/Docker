from sqlalchemy import create_engine
from random import choice, randint
import os
import time
engine=create_engine(f"mysql+mysqlconnector://{os.environ['MYSQL_USER']}:{os.environ['MYSQL_PASSWORD']}@db/{os.environ['MYSQL_DATABASE']}")
connection=engine.connect()
province=['NA','TO','RM','FI','GE','MI']
while(True):
    connection.execute(f"INSERT INTO donazioni (provincia, importo) VALUES ('{choice(province)}',{randint(10,300)})")
    time.sleep(5)
