USE solidarieta;
CREATE TABLE donazioni(
	id INT AUTO_INCREMENT PRIMARY KEY,
	provincia VARCHAR(2) NOT NULL,
	importo FLOAT
);

INSERT INTO donazioni (provincia, importo) VALUES ('NA', 350);
INSERT INTO donazioni (provincia, importo) VALUES ('TO',75);
