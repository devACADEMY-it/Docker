const express = require('express')
const mysql = require('mysql')

const pool  = mysql.createPool({
      host            : 'db',
      user            : process.env.MYSQL_USER,
      password        : process.env.MYSQL_PASSWORD,
      database	      : process.env.MYSQL_DATABASE
    });
    
const app = express()

app.use(function(req, res, next) {
	res.header("Access-Control-Allow-Origin", "*"); 
	res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  	next()
})

app.get('/donazioni/ultime',function(req,res){
    pool.query("SELECT * FROM donazioni ORDER BY id DESC LIMIT 10", (err, result, fields) => {
    	 if (err) throw err
		     res.status(200).send(JSON.stringify(result))
    })

})

app.get('/donazioni/totale',function(req,res){
    pool.query("SELECT SUM(importo) AS totale  FROM donazioni", (err, result, fields) => {
    	 if (err) throw err;
		  res.status(200).send(JSON.stringify(result))
    })

})

app.listen(4444, '0.0.0.0')
